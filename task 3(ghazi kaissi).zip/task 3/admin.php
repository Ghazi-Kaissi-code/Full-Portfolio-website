<?php
 session_start();
 if (!isset($_SESSION)) {
    session_start();
}

$userId = $_SESSION['user-id'] ?? null;
$role = $_SESSION['role'] ?? null;

if (null === $userId || $role !== 'admin') {
    header("Location: login.php");
    exit();
}

 echo "Welcome to the Admin Panel, " . $_SESSION['username'] . "!";
echo "<br><a href='dashboard.php'>Back to Dashboard</a>";
?>

?>
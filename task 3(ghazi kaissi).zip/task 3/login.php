<?php
require_once ('./db.php');
require_once ('./function.php');
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];
    
    $user = checkUser($pdo, $email, $password);
    
    if ($user) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'];
        echo "Login successful!";
        header("Location: dashboard.php");
        exit();
    } else {
        echo "Fail to register <br>";
        
        echo "check email or passwrod  <br>";
    }
}
?>


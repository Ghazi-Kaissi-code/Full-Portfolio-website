<?php
require_once('./db.php');

require_once ('./function.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $role = $_POST['role'] ?? 'user';
    
    $run = registerUser($pdo, $username, $email, $password, $role);
    echo $run;
}
?>

?>

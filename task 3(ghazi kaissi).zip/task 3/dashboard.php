<?php
session_start();
if(!isset($_SESSION['user-id'])){
    header("Location:login.php");
    exit();
    
}
echo "Welcome, " . $_SESSION['username'] . "!<br>"; 
echo "Your role is: " . $_SESSION['role'] . "<br>"; 

if($_SESSION['role'] == 'admin'){
    echo "<a href='admin.php'>Go to Admin Panel</a>";
}else{
    echo"you are a user";
}
echo "<br><a href='logout.php'>Logout</a>";
?>
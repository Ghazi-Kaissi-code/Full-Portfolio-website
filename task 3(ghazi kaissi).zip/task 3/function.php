<?php
require_once('./db.php');

//REGISTER NEW USER
function registerUser($pdo, $username, $email, $password, $role = 'user') {
    //CHECK EMAIL
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    
    if ($stmt->rowCount() > 0) {
        return "Email already exists";
    } else {
        //NEW USER
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO users (username, email, password, role) VALUES (:username, :email, :password, :role)");

        // ANOTHER EXECUTION TECHNIQUE USING BIND PARAMETERS
        $stmt->bindParam(':username', $username);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':password', $hashedPassword);
        $stmt->bindParam(':role', $role);

          if ($stmt->execute()) {
            echo "Registration successful!";
        } else {
            echo "Error in registration!";
        }
            }
    }

    
    //TO CHECK USER 
    function checkUser($pdo, $email, $password) {
       
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
        return $user && password_verify($password, $user['password']) ? $user : false;
    }
    
        
?>


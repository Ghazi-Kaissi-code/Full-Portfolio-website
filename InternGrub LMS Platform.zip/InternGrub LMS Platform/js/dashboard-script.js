$(document).ready(function () {
  //**************************************************** INTERN DASHBOARD START*************************************************//

  // DAHSBOARD TOGGLER
  $(".btn.toggler").on("click", function () {
    $("#sidebar").toggleClass("collapsed");
  });

  // INTERN DASHBOARD TEXTARE ABOUT YOURSELF
  $("#about-yourself").on("input", function () {
    var charCount = $(this).val().length;
    $("#charCount").text(charCount + " / 400 characters");
  });

  // WORK EXPERIENCE ADD MORE
  let experienceCount = 1;

  $("#add-experience-btn").click(function () {
    experienceCount++;

    const newExperienceItem = `
          <div class="experience-item mb-4">
              <div class="form-outline mb-4">
                  <input type="text" id="internship_company_${experienceCount}" class="form-control form-control-lg" placeholder="Previous Internship - Company Name" />
                  <label class="form-label pb-1" for="internship_company_${experienceCount}">Previous Internship - Company Name</label>
              </div>
              <div class="form-outline mb-4">
                  <input type="text" id="internship_role_${experienceCount}" class="form-control form-control-lg" placeholder="Role" />
                  <label class="form-label pb-1" for="internship_role_${experienceCount}">Role</label>
              </div>
              <div class="form-outline mb-4">
                  <input type="text" id="internship_duration_${experienceCount}" class="form-control form-control-lg" placeholder="Duration" />
                  <label class="form-label pb-1" for="internship_duration_${experienceCount}">Duration</label>
              </div>
              <div class="form-outline mb-4">
                  <textarea id="internship_description_${experienceCount}" class="form-control form-control-lg" placeholder="Description" rows="3"></textarea>
              </div>
              <button type="button" class="btn btn-danger mb-2" id="delete-experience-btn_${experienceCount}">Cancel</button>
          </div>
      `;
    // Append the new experience fields to the container
    $("#work-experience-container").append(newExperienceItem);

    // Add click event listener for the new cancel button
    $(`#delete-experience-btn_${experienceCount}`).click(function () {
      $(this).parent().remove(); // Remove the entire experience item
      experienceCount--;
    });
  });

  // SELECT 2 START
  $("#technical_skills").select2({
    placeholder: "Select Technical Skills",
    allowClear: true,
    width: "100%",
  });

  $("#languages").select2({
    placeholder: "Select Languages",
    allowClear: true,
    width: "100%",
  });

  $("#soft_skills").select2({
    placeholder: "Select Soft Skills",
    allowClear: true,
    width: "100%",
  });

  $("#required_skills").select2({
    placeholder: "Select required skills",
    allowClear: true,
    width: "100%",
  });

  $("#required_skills2").select2({
    placeholder: "Select required skills",
    allowClear: true,
    width: "100%",
  });
  // SELECT 2 END

  // SCROLL TO THE ACCORDION AND OPEN IT IF CLOSED
  $(".sidebar-link").on("click", function (e) {
    e.preventDefault();
    // TARGET ELEMENT FROM THE HREF ID
    var targetId = $(this).attr("href");
    // SCROLL TO TARGET ELEMENT
    $("html, body").animate(
      {
        scrollTop: $(targetId).offset().top,
      },
      500
    );
    // OPEN THE TARGET ACCORDION
    var accordionButton = $(targetId).find(".accordion-button");
    if (accordionButton.hasClass("collapsed")) {
      accordionButton.trigger("click"); // Toggle the accordion
    }
  });

  // IMAGES UPLOAD FUNCTIONALITY
  $('input[type="file"]').on("change", function (event) {
    const input = this;
    if (input.files && input.files[0]) {
      const reader = new FileReader();
      reader.onload = function (e) {
        const imgElement = $(input).siblings("img");
        imgElement.attr("src", e.target.result);
        imgElement.removeClass("w-50");
      };
      reader.readAsDataURL(input.files[0]);
    }
  });

  // QUILL TEXT AREA FOR ADDING JOB DESCRIPTION - VENDOR DASHBOARD
  var quill = new Quill("#editor-container", {
    theme: "snow",
    modules: {
      toolbar: [[{ header: [2, 3, 4, false] }], ["bold", "italic", "underline"], [{ list: "ordered" }, { list: "bullet" }]],
    },
  });

  //**************************************************** INTERN DASHBOARD END***************************************************//
});

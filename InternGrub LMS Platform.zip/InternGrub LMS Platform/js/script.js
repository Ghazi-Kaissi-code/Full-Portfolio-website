// Mobile btn toggler
$(document).ready(function () {
  $(".mobile-menu-btn").click(function () {
    $(this).toggleClass("active");
  });

  // VIDEO OVERLAY AND PLAY
  $(".video-overlay").click(function () {
    // Hide the overlay
    $(this).hide();

    // Show and play the video
    var iframe = $(".video-container iframe");
    iframe.show();
    var src = iframe.attr("src");
    iframe.attr("src", src + "&autoplay=1");
  });

  // FEEDBACK POP UP ON LOAD AFTER 10 SECONDS
  // setTimeout(function () {
  //   $("#feedbackModal").modal("show");
  // }, 10000);

  //FORMS VALIDATION BS
  const theme = {
    init: function () {
      this.validation();
    },
    validation: function () {
      const forms = $(".needs-validation");

      forms.each(function () {
        $(this).on("submit", function (event) {
          if (!this.checkValidity()) {
            event.preventDefault();
            event.stopPropagation();
          }

          $(this).addClass("was-validated");
        });
      });
    },
  };
  theme.init();

  // VENDOR FIELDS IN REGISTER PAGE TOGGLING FUNCTIONALITY
  $("#user_type").on("change", function () {
    var selectedRole = $(this).val();

    // Show fields and add 'required' if 'vendor' is selected
    if (selectedRole === "vendor") {
      $("#vendor_fields").removeClass("d-none"); // Show the fields
      $("#company_name, #position").attr("required", true); // Add required attribute
    } else {
      $("#vendor_fields").addClass("d-none"); // Hide the fields
      $("#company_name, #position").removeAttr("required"); // Remove required attribute
      $("#company_name, #position").val(""); // Clear values
    }
  });

  //********************************************** INTERNSHIP-DETAILS-PAGE-START ***********************************************//

  // WHATSAPP SHARE BTN
  $("#whatsappButton").click(function () {
    var url = encodeURIComponent(window.location.href);
    var whatsappUrl = "https://api.whatsapp.com/send?text=" + url;
    window.open(whatsappUrl, "_blank");
  });

  // TWITTER SHARE BTN
  $("#x-twitterShareButton").click(function () {
    var url = encodeURIComponent(window.location.href);
    var twitterUrl = "https://twitter.com/intent/tweet?url=" + url;
    window.open(twitterUrl, "_blank");
  });

  // FACEBOOK SHARE BTN
  $("#facebook-share-button").on("click", function () {
    const url = encodeURIComponent(window.location.href);
    const facebookShareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`;
    window.open(facebookShareUrl, "_blank");
  });

  //********************************************** INTERNSHIP-DETAILS-PAGE-END *************************************************//
});
